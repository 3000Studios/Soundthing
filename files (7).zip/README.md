# Soundthing: Lenovo Legion RF & Sensor Detector

This is a web-based, multi-sensor detection and analysis tool designed to monitor audio frequencies, system metrics, and various hardware sensors, simulating a diagnostics dashboard for a Lenovo Legion device.

This project was architected and built by **BOSS MAN COPILOT**.

## Features

- **Real-time Audio Analysis**: Spectrum visualizer, peak frequency detection, and audio level monitoring.
- **Advanced Audio Controls**: Microphone selection, gain boost, live playback, and ultrasonic mode.
- **Comprehensive Sensor Dashboard**: Monitors motion (accelerometer, gyroscope), environmental (temperature, pressure), and system sensors.
- **System Performance Metrics**: Real-time tracking of CPU, GPU, Memory, Fan Speed, and Power Consumption.
- **Network Status**: Simulated monitoring of Wi-Fi strength and Bluetooth connectivity.
- **Recording**: Capture audio sessions and download them as `.webm` files.
- **Modular & Scalable**: Built with a clean component-based structure using React.

## Tech Stack

- **Framework**: React
- **Styling**: TailwindCSS
- **Icons**: Lucide React

---

## Getting Started

Follow these instructions to get the project up and running on your local machine.

### Prerequisites

- [Node.js](https://nodejs.org/) (v16 or later recommended)
- [npm](https://www.npmjs.com/) (usually comes with Node.js)

### Installation & Setup

1.  **Clone the repository:**
    ```sh
    git clone https://github.com/3000Studios/Soundthing.git
    cd Soundthing
    ```

2.  **Install dependencies:**
    This command will install all the necessary packages defined in `package.json`.
    ```sh
    npm install
    ```

3.  **Run the development server:**
    This will start the application in development mode.
    ```sh
    npm start
    ```
    Open [http://localhost:3000](http://localhost:3000) to view it in your browser. The page will automatically reload if you make edits.

### Building for Production

To create a production-ready build of the app, run:

```sh
npm run build
```

This command bundles the app into static files in the `build` folder. It correctly bundles React in production mode and optimizes the build for the best performance.

---

## Project Structure

The project follows a component-based architecture to ensure maintainability and scalability.

```
soundthing/
├── public/               # Static assets and index.html
├── src/
│   ├── components/       # Reusable React components
│   │   ├── AudioTab.js
│   │   ├── NetworkTab.js
│   │   ├── SensorsTab.js
│   │   ├── SystemTab.js
│   │   └── FrequencyVisualizer.js
│   ├── utils/            # Helper functions
│   │   └── formatters.js
│   ├── App.js            # Main application component (state management)
│   ├── index.css         # TailwindCSS directives
│   └── index.js          # Application entry point
├── .gitignore            # Files to be ignored by Git
├── package.json          # Project dependencies and scripts
├── postcss.config.js     # PostCSS configuration
└── tailwind.config.js    # TailwindCSS configuration
```